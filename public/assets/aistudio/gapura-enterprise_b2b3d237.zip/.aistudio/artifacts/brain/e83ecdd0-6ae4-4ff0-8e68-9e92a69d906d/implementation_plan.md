# Rencana Implementasi: Jadwal dengan Layout & Live Preview Seperti Halaman Nota

Berdasarkan jawaban pengguna, halaman **Jadwal** akan dibuat persis seperti alur dan pengalaman di **Halaman Nota**:
1. **Sisi Kiri (Form Input):** Input data pemesan, waktu pasang/bongkar, PIC kru, rincian pesanan tenda & alat, serta catatan lapangan (bisa juga otomatis tarik dari nota yang ada).
2. **Sisi Kanan (Live Document Paper Preview):** Tampilan kertas dokumen nyata Surat Perintah Kerja (SPK) Jadwal dengan kop resmi Gapura Enterprise, tabel bergaris rapi, watermark, dan nomor jadwal otomatis.
3. **Action Toolbar:** Tombol aksi langsung di bawah preview kertas (Simpan ke Riwayat Jadwal, Download Foto PNG, Download PDF, Cetak Langsung, Salin Teks WhatsApp, dan Reset Form).
4. **Tanda Tangan:** Sesuai pilihan Anda, **tidak perlu tanda tangan digital** di lembar jadwal, sehingga format tetap bersih dan luas untuk rincian peralatan tenda.

---

## Tahapan Pekerjaan

### 1. Komponen Baru: `ScheduleDocumentPreview.tsx`
* Membuat komponen lembar kertas dokumen jadwal beresolusi tinggi (*live paper document preview*):
  * Kop resmi Gapura Enterprise (*Wedding & Event Solution, WA, Instagram, Alamat*).
  * Garis ganda pembatas kop surat.
  * Nomor SPK / Jadwal dan tanggal penerbitan.
  * Tabel Data Pelaksanaan Acara (Nama Tuan Hajat, No HP, Alamat, Tanggal & Jam Pasang, Tanggal & Jam Bongkar, Koordinator/PIC Kru).
  * Tabel Rincian Pesanan Tenda & Peralatan (Tabel bergaris border tegas ala Word, membagi rincian pesanan per nomor urut).
  * Kotak Catatan Khusus Lapangan.
  * Tampilan realistis kertas putih dengan bayangan (*paper shadow*) persis seperti nota.

### 2. Komponen Baru: `ScheduleActionButtons.tsx`
* Menyediakan bilah tombol aksi langsung di bawah lembar preview kertas:
  * 💾 **Simpan ke Jadwal Aktif** (menyimpan data ke storage).
  * 📸 **Unduh Gambar (PNG)** (mengekstrak dokumen kertas menjadi foto resolusi tinggi).
  * 📄 **Unduh Dokumen (PDF)** (cetak langsung ke PDF A4).
  * 🖨️ **Cetak Lembar Kerja** (buka dialog printer browser).
  * 💬 **Kirim / Salin WhatsApp** (teks ringkasan rapi untuk grup kru/pelanggan).
  * 🔄 **Reset Form** (kosongkan form untuk input agenda baru).

### 3. Pembaruan Komponen: `SchedulePage.tsx`
* Mengubah tata letak utama menjadi grid 2 kolom (Desktop: Form di kiri, Live Preview di kanan; Mobile: Stack vertikal yang nyaman).
* Menyediakan fitur *"Tarik Otomatis dari Nota Tersimpan"* sehingga pengguna bisa mengisi jadwal dengan 1 klik tanpa ketik ulang.
* Tetap menyediakan akses mudah ke **Tabel Laporan Jadwal** dan **Riwayat Jadwal Selesai**.

### 4. Responsivitas & Mode Mobile
* Pada layar handphone/mobile, seluruh menu tetap konsisten berada di **bawah layar (bottom bar)**.
* Lembar preview kertas dapat di-*scroll* secara horizontal atau pas di layar HP dengan opsi unduh yang cepat.

---

## Verifikasi
* Menjalankan `compile_applet` dan `lint_applet` untuk memastikan tidak ada kesalahan TypeScript.
* Menguji ekspor foto PNG, PDF, dan integrasi penyimpanan data jadwal.
