import React, { useState, useEffect, useRef } from 'react';
import {
  FilePlus2,
  History,
  RotateCcw,
  Sparkles,
  Printer,
  Eye,
  CheckCircle,
  FileSpreadsheet,
  Coins,
  Calendar,
  CalendarCheck,
} from 'lucide-react';
import { InvoiceData, InvoiceItem, ActiveTab, PayrollData, ScheduleItem } from './types';
import { generateInvoiceNumber } from './utils/formatters';
import {
  getInvoicesFromStorage,
  saveInvoiceToStorage,
  deleteInvoiceFromStorage,
  clearAllInvoicesFromStorage,
  updateInvoiceStatusInStorage,
  getPayrollsFromStorage,
  savePayrollToStorage,
  deletePayrollFromStorage,
  clearAllPayrollsFromStorage,
  getSchedulesFromStorage,
  saveScheduleToStorage,
  deleteScheduleFromStorage,
  updateScheduleStatusInStorage,
  clearAllSchedulesFromStorage,
} from './utils/storage';
import { Header } from './components/Header';
import { CustomerForm } from './components/CustomerForm';
import { ItemsList } from './components/ItemsList';
import { QuickCalculator } from './components/QuickCalculator';
import { SignaturePad } from './components/SignaturePad';
import { InvoicePreview } from './components/InvoicePreview';
import { ActionButtons } from './components/ActionButtons';
import { HistoryPage } from './components/HistoryPage';
import { PayrollPage } from './components/PayrollPage';
import { PayrollHistoryPage } from './components/PayrollHistoryPage';
import { SchedulePage } from './components/SchedulePage';
import { ScheduleHistoryPage } from './components/ScheduleHistoryPage';
import { ToastContainer, ToastMessage } from './components/Toast';


const createEmptyInvoice = (): InvoiceData => ({
  invoiceNumber: generateInvoiceNumber(),
  customerName: '',
  address: '',
  eventDate: '',
  downPayment: 0,
  items: [
    {
      id: '1',
      name: '',
      quantity: 1,
      price: 0,
    },
  ],
  tuanHajatSignature: null,
  hormatKamiSignature: null,
  createdAt: new Date().toISOString(),
});

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('create');
  const [invoice, setInvoice] = useState<InvoiceData>(createEmptyInvoice());
  const [historyList, setHistoryList] = useState<InvoiceData[]>([]);
  const [payrollHistoryList, setPayrollHistoryList] = useState<PayrollData[]>([]);
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [editingPayroll, setEditingPayroll] = useState<PayrollData | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const previewRef = useRef<HTMLDivElement | null>(null);

  // Load history from storage on mount
  useEffect(() => {
    const savedInvoices = getInvoicesFromStorage();
    setHistoryList(savedInvoices);

    const savedPayrolls = getPayrollsFromStorage();
    setPayrollHistoryList(savedPayrolls);

    const savedSchedules = getSchedulesFromStorage();
    setSchedules(savedSchedules);
  }, []);

  const showToast = (
    message: string,
    type: 'success' | 'info' | 'error' = 'info'
  ) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Customer details
  const handleCustomerChange = (fields: {
    customerName?: string;
    address?: string;
    eventDate?: string;
  }) => {
    setInvoice((prev) => ({
      ...prev,
      ...fields,
    }));
  };

  // Items manipulation
  const handleAddItem = () => {
    setInvoice((prev) => ({
      ...prev,
      items: [
        ...prev.items,
        {
          id: `${Date.now()}-${Math.random()}`,
          name: '',
          quantity: 1,
          price: 0,
        },
      ],
    }));
  };

  const handleRemoveItem = (index: number) => {
    if (invoice.items.length <= 1) return;
    setInvoice((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }));
  };

  const handleUpdateItem = (index: number, updates: Partial<InvoiceItem>) => {
    setInvoice((prev) => {
      const updated = [...prev.items];
      updated[index] = { ...updated[index], ...updates };
      return { ...prev, items: updated };
    });
  };

  const handleUpdateDP = (amount: number) => {
    setInvoice((prev) => ({ ...prev, downPayment: amount }));
  };

  // Signatures
  const handleSaveTuanHajatSignature = (dataUrl: string | null) => {
    setInvoice((prev) => ({ ...prev, tuanHajatSignature: dataUrl }));
  };

  const handleSaveHormatKamiSignature = (dataUrl: string | null) => {
    setInvoice((prev) => ({ ...prev, hormatKamiSignature: dataUrl }));
  };

  // Clear Form
  const handleClearForm = () => {
    if (
      invoice.customerName ||
      invoice.items.some((i) => i.name) ||
      invoice.downPayment > 0
    ) {
      if (!window.confirm('Bersihkan form dan buat nota baru?')) {
        return;
      }
    }
    setInvoice(createEmptyInvoice());
    showToast('Form telah direset untuk nota baru.', 'info');
  };

  // Save to DB
  const handleSaveToDB = () => {
    const updated = saveInvoiceToStorage(invoice);
    setHistoryList(updated);
  };

  // Load from History into Editor
  const handleLoadInvoice = (selectedInvoice: InvoiceData) => {
    setInvoice({
      ...selectedInvoice,
    });
    setActiveTab('create');
    showToast(`Nota ${selectedInvoice.customerName || selectedInvoice.invoiceNumber} dimuat ke Editor.`, 'success');
  };

  // Delete from History
  const handleDeleteInvoice = (id: string) => {
    const updated = deleteInvoiceFromStorage(id);
    setHistoryList(updated);
  };

  // Delete all from History
  const handleClearAllInvoices = () => {
    const updated = clearAllInvoicesFromStorage();
    setHistoryList(updated);
  };

  // Update status (Lunas / Belum Lunas / Auto)
  const handleUpdateInvoiceStatus = (
    id: string,
    status: 'LUNAS' | 'BELUM_LUNAS' | 'AUTO'
  ) => {
    const updated = updateInvoiceStatusInStorage(id, status);
    setHistoryList(updated);
    if (invoice.id === id || invoice.invoiceNumber === id) {
      setInvoice((prev) => ({
        ...prev,
        paymentStatus: status === 'AUTO' ? undefined : status,
      }));
    }
  };

  // ================= PAYROLL HANDLERS =================
  const handleSavePayrollToHistory = (payroll: PayrollData) => {
    const updated = savePayrollToStorage(payroll);
    setPayrollHistoryList(updated);
  };

  const handleDeletePayroll = (id: string) => {
    const updated = deletePayrollFromStorage(id);
    setPayrollHistoryList(updated);
  };

  const handleClearAllPayrolls = () => {
    const updated = clearAllPayrollsFromStorage();
    setPayrollHistoryList(updated);
  };

  const handleLoadPayrollToEditor = (selected: PayrollData) => {
    setEditingPayroll(selected);
    setActiveTab('payroll');
    showToast(`Memuat data rekap "${selected.title || selected.payrollNumber}"`, 'info');
  };

  const handleCreateNewPayroll = () => {
    setEditingPayroll(null);
    setActiveTab('payroll');
  };

  // ================= SCHEDULE / JADWAL HANDLERS =================
  const handleSaveSchedule = (newSchedule: ScheduleItem) => {
    const updated = saveScheduleToStorage(newSchedule);
    setSchedules(updated);
    showToast(`Jadwal "${newSchedule.customerName}" berhasil disimpan!`, 'success');
  };

  const handleDeleteSchedule = (id: string) => {
    const updated = deleteScheduleFromStorage(id);
    setSchedules(updated);
  };

  const handleUpdateScheduleStatus = (id: string, status: 'AKTIF' | 'SELESAI') => {
    const updated = updateScheduleStatusInStorage(id, status);
    setSchedules(updated);
  };

  const handleClearAllScheduleHistory = () => {
    const activeOnly = schedules.filter((s) => s.status === 'AKTIF');
    localStorage.setItem('gapura_enterprise_schedules_v1', JSON.stringify(activeOnly));
    setSchedules(activeOnly);
  };

  const activeScheduleCount = schedules.filter((s) => s.status === 'AKTIF').length;
  const completedScheduleCount = schedules.filter((s) => s.status === 'SELESAI').length;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col antialiased">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onReset={handleClearForm}
        historyCount={historyList.length}
        payrollHistoryCount={payrollHistoryList.length}
        activeScheduleCount={activeScheduleCount}
        scheduleHistoryCount={completedScheduleCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 mb-16 md:mb-6">
        {activeTab === 'schedule' ? (
          <SchedulePage
            schedules={schedules}
            availableInvoices={historyList}
            onSaveSchedule={handleSaveSchedule}
            onDeleteSchedule={handleDeleteSchedule}
            onUpdateStatus={handleUpdateScheduleStatus}
            onNavigateToHistory={() => setActiveTab('schedule-history')}
            onShowToast={showToast}
          />
        ) : activeTab === 'schedule-history' ? (
          <ScheduleHistoryPage
            schedules={schedules}
            onDeleteSchedule={handleDeleteSchedule}
            onClearAllHistory={handleClearAllScheduleHistory}
            onUpdateStatus={handleUpdateScheduleStatus}
            onNavigateToActive={() => setActiveTab('schedule')}
            onShowToast={showToast}
          />
        ) : activeTab === 'history' ? (
          <HistoryPage
            invoices={historyList}
            onLoadInvoice={handleLoadInvoice}
            onDeleteInvoice={handleDeleteInvoice}
            onClearAllInvoices={handleClearAllInvoices}
            onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
            onShowToast={showToast}
          />
        ) : activeTab === 'payroll-history' ? (
          <PayrollHistoryPage
            payrolls={payrollHistoryList}
            onLoadPayroll={handleLoadPayrollToEditor}
            onDeletePayroll={handleDeletePayroll}
            onClearAllPayrolls={handleClearAllPayrolls}
            onCreateNewPayroll={handleCreateNewPayroll}
            onShowToast={showToast}
          />
        ) : activeTab === 'payroll' ? (
          <PayrollPage
            onShowToast={showToast}
            onSaveToHistory={handleSavePayrollToHistory}
            onNavigateToHistory={() => setActiveTab('payroll-history')}
            initialPayrollData={editingPayroll}
            historyCount={payrollHistoryList.length}
          />
        ) : (
          <div className="space-y-4">
            {/* Quick Access to Jadwal Banner (Desktop Only) */}
            <div className="hidden md:flex bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-amber-500/5 border border-amber-300/70 rounded-2xl p-4 flex-row items-center justify-between gap-3 shadow-sm bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#8B0000] text-[#bef264] flex items-center justify-center font-bold shadow-md shrink-0">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-extrabold text-slate-800 text-base">
                      📅 Menu Jadwal Pasang & Bongkar Tenda
                    </span>
                    <span className="bg-[#8B0000] text-[#bef264] text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Aktif & Siap Pakai
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Catat nama tuan hajat, no HP, alamat, rincian pesanan, tgl pasang/bongkar & bagikan via Tabel Word / PDF / WhatsApp!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  id="banner-btn-open-schedule"
                  type="button"
                  onClick={() => setActiveTab('schedule')}
                  className="flex items-center justify-center gap-1.5 px-4 py-2 bg-[#8B0000] text-white hover:bg-[#700000] text-xs font-bold rounded-xl shadow-md transition"
                >
                  <Calendar className="w-4 h-4 text-[#bef264]" />
                  <span>Buka Jadwal ({activeScheduleCount})</span>
                </button>
                <button
                  id="banner-btn-open-schedule-history"
                  type="button"
                  onClick={() => setActiveTab('schedule-history')}
                  className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition"
                >
                  <CalendarCheck className="w-4 h-4 text-emerald-600" />
                  <span>Riwayat Jadwal ({completedScheduleCount})</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Form & Inputs */}
              <div className="lg:col-span-6 space-y-4">
                {/* Section 1: Customer Info */}
                <CustomerForm
                  customerName={invoice.customerName}
                  address={invoice.address}
                  eventDate={invoice.eventDate}
                  onChange={handleCustomerChange}
                />

                {/* Section 2: Items & DP */}
                <ItemsList
                  items={invoice.items}
                  downPayment={invoice.downPayment}
                  onAddItem={handleAddItem}
                  onRemoveItem={handleRemoveItem}
                  onUpdateItem={handleUpdateItem}
                  onUpdateDP={handleUpdateDP}
                />

                {/* Section 3: Quick Calculator */}
                <QuickCalculator
                  onApplyToDP={handleUpdateDP}
                />

                {/* Section 4: Dual Signatures */}
                <div id="signatures-section" className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold tracking-wider text-[#8B0000] uppercase">
                      Tanda Tangan Digital
                    </h3>
                    <span className="text-[11px] text-slate-500">
                      Otomatis masuk ke cetakan
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <SignaturePad
                      label="Tanda Tangan Tuan Hajat"
                      signatureData={invoice.tuanHajatSignature}
                      onSave={handleSaveTuanHajatSignature}
                      idPrefix="sig-tuan-hajat"
                    />

                    <SignaturePad
                      label="Tanda Tangan Hormat Kami"
                      signatureData={invoice.hormatKamiSignature}
                      onSave={handleSaveHormatKamiSignature}
                      idPrefix="sig-hormat-kami"
                    />
                  </div>
                </div>
              </div>

              {/* Right Column: Live Invoice Preview & Actions */}
              <div className="lg:col-span-6 space-y-4 lg:sticky lg:top-20">
                <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
                    <div className="flex items-center gap-1.5 text-xs font-bold tracking-wider text-slate-700 uppercase">
                      <Eye className="w-4 h-4 text-[#8B0000]" />
                      <span>PREVIEW NOTA CETAK</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 font-medium">
                      {invoice.invoiceNumber}
                    </span>
                  </div>

                  {/* Printable Paper Container */}
                  <div className="overflow-x-auto bg-slate-100/70 p-2 sm:p-4 rounded-lg border border-slate-200/80">
                    <InvoicePreview ref={previewRef} invoice={invoice} />
                  </div>

                  {/* Action Buttons */}
                  <div className="mt-4">
                    <ActionButtons
                      invoice={invoice}
                      previewRef={previewRef}
                      onSaveToDB={handleSaveToDB}
                      onClearForm={handleClearForm}
                      onShowToast={showToast}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Mobile Bottom Navigation Bar (ONLY navigation bar on Mobile) */}
      <nav
        id="mobile-bottom-nav"
        className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 py-1.5 px-1 flex justify-around items-center z-40 shadow-xl"
      >
        <button
          id="tab-btn-create-mobile"
          type="button"
          onClick={() => setActiveTab('create')}
          className={`flex flex-col items-center gap-0.5 py-1 px-1.5 rounded-xl transition ${
            activeTab === 'create'
              ? 'text-[#8B0000] font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <FilePlus2 className="w-4 h-4" />
          <span className="text-[10px]">Nota</span>
        </button>

        <button
          id="tab-btn-schedule-mobile"
          type="button"
          onClick={() => setActiveTab('schedule')}
          className={`flex flex-col items-center gap-0.5 py-1 px-1.5 rounded-xl transition relative ${
            activeTab === 'schedule'
              ? 'text-[#8B0000] font-black'
              : 'text-amber-700 font-bold hover:text-slate-800'
          }`}
        >
          <div className="relative">
            <Calendar className="w-4 h-4 text-emerald-600" />
            {activeScheduleCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-[#8B0000] text-white text-[8px] font-bold px-1 rounded-full">
                {activeScheduleCount}
              </span>
            )}
          </div>
          <span className="text-[10px]">Jadwal</span>
        </button>

        <button
          id="tab-btn-schedule-history-mobile"
          type="button"
          onClick={() => setActiveTab('schedule-history')}
          className={`flex flex-col items-center gap-0.5 py-1 px-1.5 rounded-xl transition relative ${
            activeTab === 'schedule-history'
              ? 'text-[#8B0000] font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <CalendarCheck className="w-4 h-4 text-emerald-600" />
          <span className="text-[10px]">Riw. Jadwal</span>
        </button>

        <button
          id="tab-btn-payroll-mobile"
          type="button"
          onClick={() => setActiveTab('payroll')}
          className={`flex flex-col items-center gap-0.5 py-1 px-1.5 rounded-xl transition ${
            activeTab === 'payroll' || activeTab === 'payroll-history'
              ? 'text-[#8B0000] font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span className="text-[10px]">Gaji</span>
        </button>

        <button
          id="tab-btn-history-mobile"
          type="button"
          onClick={() => setActiveTab('history')}
          className={`flex flex-col items-center gap-0.5 py-1 px-1.5 rounded-xl transition ${
            activeTab === 'history'
              ? 'text-[#8B0000] font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          <span className="text-[10px]">Riw. Nota</span>
        </button>
      </nav>


      {/* Notification Toast Stack */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
