import React, { forwardRef, useMemo } from 'react';
import { ScheduleItem } from '../types';
import { formatDateTimeIndo } from '../utils/formatters';

interface ScheduleDocumentPreviewProps {
  schedule: ScheduleItem;
}

export const ScheduleDocumentPreview = forwardRef<HTMLDivElement, ScheduleDocumentPreviewProps>(
  ({ schedule }, ref) => {
    // Parse order items line by line into structured table rows
    const orderItemsList = useMemo(() => {
      if (!schedule?.orderDetails) return [];
      return schedule.orderDetails
        .split('\n')
        .map((item) => item.trim())
        .filter(Boolean);
    }, [schedule?.orderDetails]);

    const spkNumber = schedule.sourceInvoiceNumber
      ? `SPK-${schedule.sourceInvoiceNumber}`
      : `SPK-GAPURA-${schedule.id ? schedule.id.slice(-6).toUpperCase() : 'BARU'}`;

    return (
      <div
        id="schedule-paper"
        ref={ref}
        style={{
          width: '100%',
          maxWidth: '680px',
          margin: '0 auto',
          backgroundColor: '#ffffff',
          color: '#000000',
          border: '4px solid #8b0000',
          padding: '16px 18px',
          boxSizing: 'border-box',
          fontFamily:
            "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
          boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
        }}
        className="schedule-document-paper select-none leading-tight"
      >

        {/* DOCUMENT TITLE & SPK HEADER */}
        <div className="border-b-2 border-black pb-2 mb-3 text-center">
          <div className="text-[10px] sm:text-xs text-slate-700 font-mono mb-1 font-bold">
            NOMOR SPK: <strong>{spkNumber}</strong>
          </div>

          <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider text-[#8B0000]">
            SURAT PERINTAH KERJA (SPK) & JADWAL PASANG BONGKAR TENDA
          </h2>
          <p className="text-[9.5px] text-slate-500 italic mt-0.5">
            Lembar resmi instruksi kerja lapangan kru tenda & peralatan pesta
          </p>
        </div>

        {/* TABEL 1: DATA ACARA & PELAKSANAAN (Format Tabel Word Bergaris Rapi) */}
        <div className="mb-3">
          <div className="text-[10.5px] font-bold uppercase text-slate-900 mb-1 flex items-center gap-1">
            <span>I. DATA PEMESAN & PELAKSANAAN:</span>
          </div>
          <table className="w-full text-[11px] border-collapse border border-black table-fixed">
            <tbody>
              <tr>
                <td className="w-32 sm:w-36 border border-black bg-slate-100 p-2 font-bold text-slate-900 align-middle">
                  Nama Tuan Hajat
                </td>
                <td className="border border-black p-2 font-bold text-slate-950 text-xs sm:text-sm align-middle">
                  {schedule.customerName || (
                    <span className="text-slate-400 italic font-normal">Belum diisi</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="border border-black bg-slate-100 p-2 font-bold text-slate-900 align-top">
                  Alamat Acara / Lokasi
                </td>
                <td className="border border-black p-2 text-slate-800 leading-snug align-top">
                  {schedule.address || (
                    <span className="text-slate-400 italic">
                      Alamat lengkap lokasi pemasangan tenda belum diisi
                    </span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="border border-black bg-slate-100 p-2 font-bold text-slate-900 align-middle">
                  Waktu Pasang
                </td>
                <td className="border border-black p-2 font-bold text-[#8B0000] align-middle">
                  {schedule.setupDate ? (
                    formatDateTimeIndo(schedule.setupDate)
                  ) : (
                    <span className="text-slate-400 italic font-normal">Belum ditentukan</span>
                  )}
                </td>
              </tr>
              <tr>
                <td className="border border-black bg-slate-100 p-2 font-bold text-slate-900 align-middle">
                  Waktu Bongkar
                </td>
                <td className="border border-black p-2 font-bold text-[#8B0000] align-middle">
                  {schedule.teardownDate ? (
                    formatDateTimeIndo(schedule.teardownDate)
                  ) : (
                    <span className="text-slate-400 italic font-normal">Belum ditentukan</span>
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* TABEL 2: RINCIAN PESANAN TENDA & PERALATAN */}
        <div className="mb-3">
          <div className="text-[10.5px] font-bold uppercase text-slate-900 mb-1 flex items-center justify-between">
            <span>II. RINCIAN PESANAN TENDA & PERALATAN:</span>
            <span className="text-[9px] font-normal text-slate-500 italic">
              *Wajib diperiksa saat muat & pasang di lokasi
            </span>
          </div>

          <table className="w-full text-[11px] border-collapse border border-black">
            <thead>
              <tr className="bg-slate-200 text-black font-bold">
                <th className="border border-black p-1 text-center w-8">No</th>
                <th className="border border-black p-1 text-left">Uraian Peralatan / Tenda</th>
                <th className="border border-black p-1 text-center w-24">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {orderItemsList.length > 0 ? (
                orderItemsList.map((item, idx) => (
                  <tr key={idx} className={idx % 2 === 1 ? 'bg-slate-50/70' : ''}>
                    <td className="border border-black p-1 text-center font-bold">{idx + 1}</td>
                    <td className="border border-black p-1 font-medium">{item}</td>
                    <td className="border border-black p-1 text-center text-[10px] text-slate-700">
                      Sesuai Pesanan
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3} className="border border-black p-3 text-center text-slate-400 italic">
                    Belum ada rincian peralatan tenda yang dimasukkan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* TABEL 3: CATATAN KHUSUS LAPANGAN (JIKA ADA) */}
        {schedule.notes && (
          <div className="mb-3">
            <div className="text-[10.5px] font-bold uppercase text-slate-900 mb-1">
              III. CATATAN KHUSUS & KETENTUAN LAPANGAN:
            </div>
            <div className="border border-black bg-slate-50 p-2 text-[10.5px] text-slate-800 leading-snug">
              <strong>Catatan Lapangan:</strong> {schedule.notes}
            </div>
          </div>
        )}

        {/* FOOTER & WATERMARK (Clean, without digital signature pad) */}
        <div className="pt-2 border-t border-slate-300 flex items-center justify-between text-[8.5px] text-slate-500 font-mono">
          <span>Gapura Enterprise Wedding Solution</span>
          <span>Dicetak: {new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</span>
          <span>Lembar Kerja Resmi Tim Lapangan</span>
        </div>
      </div>
    );
  }
);
ScheduleDocumentPreview.displayName = 'ScheduleDocumentPreview';
