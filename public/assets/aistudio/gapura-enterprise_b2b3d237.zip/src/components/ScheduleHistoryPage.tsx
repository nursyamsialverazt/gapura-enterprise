import React, { useState, useMemo } from 'react';
import {
  CalendarCheck,
  Search,
  RotateCcw,
  Trash2,
  Share2,
  Calendar,
  Clock,
  MapPin,
  Phone,
  HardHat,
  ArrowLeft,
  CheckCircle2,
  Table,
  LayoutGrid,
} from 'lucide-react';
import { ScheduleItem } from '../types';
import { formatDateTimeIndo } from '../utils/formatters';
import { ScheduleShareModal } from './ScheduleShareModal';
import { ScheduleTableReport } from './ScheduleTableReport';

interface ScheduleHistoryPageProps {
  schedules: ScheduleItem[];
  onDeleteSchedule: (id: string) => void;
  onClearAllHistory: () => void;
  onUpdateStatus: (id: string, status: 'AKTIF' | 'SELESAI') => void;
  onNavigateToActive: () => void;
  onShowToast: (message: string, type?: 'success' | 'info' | 'error') => void;
}

export const ScheduleHistoryPage: React.FC<ScheduleHistoryPageProps> = ({
  schedules,
  onDeleteSchedule,
  onClearAllHistory,
  onUpdateStatus,
  onNavigateToActive,
  onShowToast,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'table' | 'card'>('table');
  const [sharingSchedule, setSharingSchedule] = useState<ScheduleItem | null>(null);

  // Filter completed schedules
  const completedSchedules = useMemo(() => {
    return schedules.filter((s) => s.status === 'SELESAI');
  }, [schedules]);

  const filteredList = useMemo(() => {
    if (!searchTerm.trim()) return completedSchedules;
    const query = searchTerm.toLowerCase();
    return completedSchedules.filter((s) => {
      const matchName = (s.customerName || '').toLowerCase().includes(query);
      const matchAddress = (s.address || '').toLowerCase().includes(query);
      const matchPhone = (s.phone || '').includes(query);
      const matchOrder = (s.orderDetails || '').toLowerCase().includes(query);
      const matchPic = (s.picCrew || '').toLowerCase().includes(query);
      return matchName || matchAddress || matchPhone || matchOrder || matchPic;
    });
  }, [completedSchedules, searchTerm]);

  const handleDelete = (id: string) => {
    if (window.confirm('Hapus riwayat jadwal ini secara permanen?')) {
      onDeleteSchedule(id);
      onShowToast('Riwayat jadwal telah dihapus', 'info');
    }
  };

  const handleClearAll = () => {
    if (completedSchedules.length === 0) return;
    if (
      window.confirm(
        'PERINGATAN: Apakah Anda yakin ingin menghapus SEMUA riwayat jadwal yang sudah selesai?'
      )
    ) {
      onClearAllHistory();
      onShowToast('Semua riwayat jadwal selesai berhasil dibersihkan', 'info');
    }
  };

  const handleRestore = (id: string) => {
    onUpdateStatus(id, 'AKTIF');
    onShowToast('Jadwal berhasil dikembalikan ke status AKTIF!', 'success');
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-700">
              <CalendarCheck className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Riwayat Jadwal Selesai & Bongkar
            </h2>
          </div>
          <p className="text-xs text-slate-500">
            Arsip seluruh kegiatan pesta/acara yang sudah selesai dibongkar oleh tim kru Gapura
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* View Mode Switcher */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              id="btn-history-view-table"
              type="button"
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                viewMode === 'table'
                  ? 'bg-[#8B0000] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>Tabel Laporan</span>
            </button>

            <button
              id="btn-history-view-card"
              type="button"
              onClick={() => setViewMode('card')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                viewMode === 'card'
                  ? 'bg-white text-[#8B0000] shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Kartu Jadwal</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onNavigateToActive}
            className="px-3.5 py-2.5 bg-[#8B0000] hover:bg-[#700000] text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm"
          >
            <ArrowLeft className="w-4 h-4 text-[#bef264]" />
            <span>Kembali ke Jadwal Aktif</span>
          </button>

          {completedSchedules.length > 0 && (
            <button
              type="button"
              onClick={handleClearAll}
              className="px-3 py-2.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-semibold rounded-xl transition flex items-center gap-1.5"
              title="Bersihkan seluruh data riwayat selesai"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Bersihkan Riwayat</span>
            </button>
          )}
        </div>
      </div>

      {/* Conditional: Table Report vs Cards */}
      {viewMode === 'table' ? (
        <ScheduleTableReport
          schedules={completedSchedules}
          title="Laporan Riwayat Pemasangan & Bongkar Tenda (Selesai)"
          isHistory={true}
          onDelete={handleDelete}
          onShare={(s) => setSharingSchedule(s)}
          onToggleStatus={(id) => handleRestore(id)}
          onShowToast={onShowToast}
        />
      ) : (
        <>
          {/* Search Bar */}
          <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Cari arsip jadwal selesai berdasarkan nama, alamat, no HP, atau barang..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8B0000] bg-slate-50 focus:bg-white"
              />
            </div>
            <span className="text-xs font-bold text-slate-500 whitespace-nowrap">
              Total: {filteredList.length} acara
            </span>
          </div>

          {/* Cards List */}
          {filteredList.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredList.map((schedule) => (
                <div
                  key={schedule.id}
                  className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-5 flex flex-col justify-between space-y-3 hover:border-slate-300 transition"
                >
                  <div>
                    {/* Header Status */}
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        Sudah Dibongkar
                      </span>
                      {schedule.sourceInvoiceNumber && (
                        <span className="text-[10px] font-mono text-slate-400">
                          {schedule.sourceInvoiceNumber}
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-slate-900 leading-tight">
                      {schedule.customerName || 'Tanpa Nama'}
                    </h3>

                    <div className="mt-2 space-y-1 text-xs text-slate-600">
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-mono">{schedule.phone || '-'}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{schedule.address || '-'}</span>
                      </div>
                    </div>

                    {/* Date Summary */}
                    <div className="mt-3 p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-xs space-y-1">
                      <div className="flex justify-between text-slate-600">
                        <span className="text-slate-400 font-medium">Pasang:</span>
                        <span className="font-semibold text-slate-800">
                          {formatDateTimeIndo(schedule.setupDate)}
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span className="text-slate-400 font-medium">Bongkar:</span>
                        <span className="font-semibold text-slate-800">
                          {formatDateTimeIndo(schedule.teardownDate)}
                        </span>
                      </div>
                      {schedule.picCrew && (
                        <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200/60">
                          <span className="text-slate-400 font-medium">PIC Kru:</span>
                          <span className="font-semibold text-slate-800">{schedule.picCrew}</span>
                        </div>
                      )}
                    </div>

                    {/* Items brief */}
                    {schedule.orderDetails && (
                      <div className="mt-2 text-xs font-mono text-slate-500 line-clamp-2 bg-slate-50/50 p-2 rounded-lg border border-slate-100">
                        {schedule.orderDetails}
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setSharingSchedule(schedule)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#8B0000] hover:bg-[#700000] text-white rounded-xl text-xs font-bold transition shadow-sm"
                      title="Bagikan atau cetak ulang lembar kerja"
                    >
                      <Share2 className="w-3.5 h-3.5 text-[#bef264]" />
                      <span>Bagikan</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleRestore(schedule.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition"
                        title="Pulihkan kembali ke jadwal aktif"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-amber-600" />
                        <span className="hidden sm:inline">Pulihkan</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDelete(schedule.id)}
                        className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition"
                        title="Hapus dari riwayat"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                <CalendarCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">
                  Belum ada riwayat jadwal selesai
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Saat pekerjaan tenda dan acara sudah selesai dibongkar, klik tombol "Selesai Bongkar"
                  pada menu Jadwal untuk mengarsipkannya ke halaman ini.
                </p>
              </div>
              <button
                type="button"
                onClick={onNavigateToActive}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#8B0000] text-white text-xs font-bold rounded-xl hover:bg-[#700000] transition shadow-sm"
              >
                <ArrowLeft className="w-4 h-4 text-[#bef264]" />
                <span>Ke Jadwal Aktif</span>
              </button>
            </div>
          )}
        </>
      )}

      {/* Share / Export Modal */}
      <ScheduleShareModal
        isOpen={!!sharingSchedule}
        schedule={sharingSchedule}
        onClose={() => setSharingSchedule(null)}
        onShowToast={onShowToast}
      />
    </div>
  );
};
