import React, { useState, useRef, useMemo } from 'react';
import {
  Calendar,
  CalendarCheck,
  Table,
  Eye,
  Plus,
  FileText,
  User,
  MapPin,
  Clock,
  Sparkles,
} from 'lucide-react';
import { ScheduleItem, InvoiceData } from '../types';
import { ScheduleDocumentPreview } from './ScheduleDocumentPreview';
import { ScheduleActionButtons } from './ScheduleActionButtons';
import { ScheduleTableReport } from './ScheduleTableReport';
import { ScheduleShareModal } from './ScheduleShareModal';

interface SchedulePageProps {
  schedules: ScheduleItem[];
  availableInvoices: InvoiceData[];
  onSaveSchedule: (schedule: ScheduleItem) => void;
  onDeleteSchedule: (id: string) => void;
  onUpdateStatus: (id: string, status: 'AKTIF' | 'SELESAI') => void;
  onNavigateToHistory: () => void;
  onShowToast: (message: string, type?: 'success' | 'info' | 'error') => void;
}

const getDefaultDateTime = (daysAhead: number, hours: number, minutes: number = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + daysAhead);
  d.setHours(hours, minutes, 0, 0);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const createInitialSchedule = (): ScheduleItem => ({
  id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
  customerName: '',
  address: '',
  phone: '',
  orderDetails: '• Tenda Plafon VIP (4 x 10 m)\n• Panggung Pelaminan Lengkap\n• Kursi Futura + Cover (100 Pcs)\n• Meja Prasmanan + Skirting (4 Set)\n• Kipas Blower Air (2 Unit)\n• Sound System Standard',
  setupDate: getDefaultDateTime(1, 8, 30),
  teardownDate: getDefaultDateTime(3, 9, 0),
  notes: 'Harap perhatikan kabel listrik PLN dan koordinasi akses jalan dengan ketua RT setempat.',
  status: 'AKTIF',
  createdAt: new Date().toISOString(),
});

export const SchedulePage: React.FC<SchedulePageProps> = ({
  schedules,
  availableInvoices,
  onSaveSchedule,
  onDeleteSchedule,
  onUpdateStatus,
  onNavigateToHistory,
  onShowToast,
}) => {
  // Navigation tabs within Schedule Page
  const [activeView, setActiveView] = useState<'editor' | 'table'>('editor');

  // Currently loaded schedule in the 2-column live editor
  const [currentSchedule, setCurrentSchedule] = useState<ScheduleItem>(createInitialSchedule);

  // Sharing modal for table actions
  const [sharingSchedule, setSharingSchedule] = useState<ScheduleItem | null>(null);

  // Ref to the live schedule paper document
  const previewRef = useRef<HTMLDivElement>(null);

  // Active schedules only
  const activeSchedules = useMemo(() => {
    return schedules.filter((s) => s.status === 'AKTIF');
  }, [schedules]);

  // Handle switching to a new empty schedule
  const handleCreateNew = () => {
    setCurrentSchedule(createInitialSchedule());
    setActiveView('editor');
    onShowToast('Form jadwal baru siap diisi!', 'info');
  };

  // Handle editing an existing schedule (from table report)
  const handleEditFromTable = (schedule: ScheduleItem) => {
    setCurrentSchedule(schedule);
    setActiveView('editor');
    onShowToast(`Memuat jadwal ${schedule.customerName || 'pelanggan'} ke editor`, 'info');
  };

  // Handle auto-prefill from an existing invoice
  const handleSelectInvoice = (invoiceId: string) => {
    if (!invoiceId) return;
    const inv = availableInvoices.find((i) => i.id === invoiceId || i.invoiceNumber === invoiceId);
    if (!inv) return;

    let itemsFormatted = '';
    if (inv.items && inv.items.length > 0) {
      itemsFormatted = inv.items
        .filter((item) => item.name && item.name.trim())
        .map((item) => `• ${item.name} (${item.quantity}x)`)
        .join('\n');
    }

    setCurrentSchedule((prev) => ({
      ...prev,
      customerName: inv.customerName || prev.customerName,
      address: inv.address || prev.address,
      orderDetails: itemsFormatted || prev.orderDetails,
      sourceInvoiceId: inv.id || inv.invoiceNumber,
      sourceInvoiceNumber: inv.invoiceNumber,
    }));

    onShowToast(`Data dari Nota #${inv.invoiceNumber} berhasil disalin ke form jadwal!`, 'success');
  };

  // Quick append item to order details
  const handleAppendItem = (itemText: string) => {
    setCurrentSchedule((prev) => {
      const current = prev.orderDetails ? prev.orderDetails.trim() : '';
      const addition = `• ${itemText}`;
      const newDetails = current ? `${current}\n${addition}` : addition;
      return { ...prev, orderDetails: newDetails };
    });
  };

  // Save current schedule
  const handleSaveCurrentSchedule = () => {
    if (!currentSchedule.customerName.trim()) {
      onShowToast('Mohon isi Nama Tuan Hajat terlebih dahulu', 'error');
      return;
    }
    if (!currentSchedule.setupDate || !currentSchedule.teardownDate) {
      onShowToast('Mohon tentukan Tanggal Pasang dan Bongkar', 'error');
      return;
    }

    onSaveSchedule(currentSchedule);
    onShowToast('Jadwal kerja berhasil disimpan ke database!', 'success');
  };

  // Reset current schedule
  const handleResetCurrentSchedule = () => {
    if (window.confirm('Bersihkan form dan mulai jadwal baru?')) {
      setCurrentSchedule(createInitialSchedule());
      onShowToast('Form jadwal berhasil direset', 'info');
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-[#8B0000]/10 text-[#8B0000]">
              <Calendar className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Jadwal Pemasangan & Bongkar Tenda
            </h2>
            <span className="bg-amber-100 text-amber-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-amber-300">
              {activeSchedules.length} Aktif
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Formulir kerja kru lapangan dengan live preview lembar kerja tabel standar Gapura Enterprise
          </p>
        </div>

        {/* Top View Mode Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Toggle Editor vs Tabel Laporan */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              id="btn-view-editor"
              type="button"
              onClick={() => setActiveView('editor')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeView === 'editor'
                  ? 'bg-[#8B0000] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Editor (Live Preview Kertas)</span>
            </button>

            <button
              id="btn-view-table-report"
              type="button"
              onClick={() => setActiveView('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                activeView === 'table'
                  ? 'bg-[#8B0000] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>Tabel Laporan ({activeSchedules.length})</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onNavigateToHistory}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 transition flex items-center gap-1.5"
          >
            <CalendarCheck className="w-4 h-4 text-emerald-600" />
            <span>Riwayat Selesai</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: EDITOR 2-KOLOM (PERSIS SEPERTI NOTA DENGAN LIVE PREVIEW KERTAS) */}
      {activeView === 'editor' ? (
        <div className="space-y-4">
          {/* Quick Toolbar: Import from Nota or Switch Saved Schedules */}
          <div className="bg-white rounded-xl p-3.5 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap flex-1">
              {/* Ambil dari Nota */}
              {availableInvoices && availableInvoices.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-[#8B0000] whitespace-nowrap flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    Ambil dari Nota:
                  </span>
                  <select
                    id="select-prefill-invoice"
                    onChange={(e) => {
                      handleSelectInvoice(e.target.value);
                      e.target.value = '';
                    }}
                    defaultValue=""
                    className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#8B0000] text-slate-700 max-w-[200px]"
                  >
                    <option value="" disabled>
                      Pilih nota tersimpan...
                    </option>
                    {availableInvoices.map((inv) => (
                      <option key={inv.id || inv.invoiceNumber} value={inv.id || inv.invoiceNumber}>
                        {inv.invoiceNumber} - {inv.customerName || 'Tanpa Nama'}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Buka Jadwal Aktif Lainnya */}
              {activeSchedules.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-slate-600 whitespace-nowrap">
                    Buka Jadwal:
                  </span>
                  <select
                    id="select-active-schedule"
                    onChange={(e) => {
                      const found = activeSchedules.find((s) => s.id === e.target.value);
                      if (found) setCurrentSchedule(found);
                      e.target.value = '';
                    }}
                    defaultValue=""
                    className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#8B0000] text-slate-700 max-w-[200px]"
                  >
                    <option value="" disabled>
                      Pilih jadwal aktif...
                    </option>
                    {activeSchedules.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.customerName || 'Tanpa Nama'} ({s.setupDate.slice(5, 10)})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <button
              id="btn-create-new-schedule"
              type="button"
              onClick={handleCreateNew}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#8B0000] hover:bg-[#700000] text-white text-xs font-bold rounded-lg shadow-sm transition shrink-0"
            >
              <Plus className="w-3.5 h-3.5 text-[#bef264]" />
              <span>+ Buat Jadwal Baru</span>
            </button>
          </div>

          {/* 2-Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Form & Inputs */}
            <div className="lg:col-span-6 space-y-4">
              {/* Bagian 1: Data Tuan Hajat / Pelanggan */}
              <div className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-xs font-bold tracking-wider text-[#8B0000] uppercase flex items-center gap-1.5">
                    <User className="w-4 h-4 text-[#8B0000]" />
                    <span>1. Data Tuan Hajat & Lokasi</span>
                  </h3>
                  {currentSchedule.sourceInvoiceNumber && (
                    <span className="text-[10px] bg-slate-100 text-slate-700 font-mono px-2 py-0.5 rounded-full border border-slate-200">
                      Terkait Nota: #{currentSchedule.sourceInvoiceNumber}
                    </span>
                  )}
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Nama Tuan Hajat / Pemesan <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Bpk. H. Ahmad Fauzi / Bu Sri Rahayu"
                      value={currentSchedule.customerName}
                      onChange={(e) =>
                        setCurrentSchedule((prev) => ({ ...prev, customerName: e.target.value }))
                      }
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8B0000] bg-slate-50 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>Alamat Lengkap Lokasi Pemasangan Tenda</span>
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Contoh: Jl. Merdeka No. 45 RT 03/RW 02, Sukamaju (Belakang Balai Desa)"
                      value={currentSchedule.address}
                      onChange={(e) =>
                        setCurrentSchedule((prev) => ({ ...prev, address: e.target.value }))
                      }
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8B0000] bg-slate-50 focus:bg-white resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* Bagian 2: Waktu Pasang & Bongkar */}
              <div className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-xs font-bold tracking-wider text-[#8B0000] uppercase flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-[#8B0000]" />
                    <span>2. Jadwal Waktu Kerja Lapangan</span>
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl space-y-1.5">
                    <label className="block text-xs font-black text-amber-900 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-amber-700" />
                      <span>Tgl & Jam Pasang <span className="text-rose-500">*</span></span>
                    </label>
                    <input
                      type="datetime-local"
                      value={currentSchedule.setupDate}
                      onChange={(e) =>
                        setCurrentSchedule((prev) => ({ ...prev, setupDate: e.target.value }))
                      }
                      className="w-full text-xs font-bold px-2.5 py-1.5 border border-amber-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-800"
                    />
                    <p className="text-[10px] text-amber-700">Waktu tim mulai mendirikan tenda</p>
                  </div>

                  <div className="p-3 bg-blue-50/60 border border-blue-200 rounded-xl space-y-1.5">
                    <label className="block text-xs font-black text-blue-900 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-blue-700" />
                      <span>Tgl & Jam Bongkar <span className="text-rose-500">*</span></span>
                    </label>
                    <input
                      type="datetime-local"
                      value={currentSchedule.teardownDate}
                      onChange={(e) =>
                        setCurrentSchedule((prev) => ({ ...prev, teardownDate: e.target.value }))
                      }
                      className="w-full text-xs font-bold px-2.5 py-1.5 border border-blue-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                    />
                    <p className="text-[10px] text-blue-700">Waktu tim membongkar & merapikan</p>
                  </div>
                </div>
              </div>

              {/* Bagian 3: Rincian Pesanan / Peralatan */}
              <div className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-xs font-bold tracking-wider text-[#8B0000] uppercase flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-[#8B0000]" />
                    <span>3. Rincian Pesanan & Peralatan Tenda</span>
                  </h3>
                  <span className="text-[11px] text-slate-500">1 baris per item peralatan</span>
                </div>

                <div>
                  <textarea
                    rows={6}
                    placeholder="Tuliskan rincian peralatan (satu per baris)&#10;Contoh:&#10;• Tenda Plafon VIP 4x12&#10;• Panggung Pelaminan 3x6&#10;• Kursi Futura 120 Pcs&#10;• Sound System Standard"
                    value={currentSchedule.orderDetails}
                    onChange={(e) =>
                      setCurrentSchedule((prev) => ({ ...prev, orderDetails: e.target.value }))
                    }
                    className="w-full font-mono text-xs px-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8B0000] bg-slate-50 focus:bg-white resize-y"
                  />

                  {/* Quick Preset Item Chips */}
                  <div className="mt-2">
                    <span className="text-[10px] font-bold text-slate-500 block mb-1">
                      Klik cepat untuk menambah peralatan:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        'Tenda Plafon VIP',
                        'Panggung Pelaminan',
                        'Kursi Futura + Cover',
                        'Meja Prasmanan (Set)',
                        'Kipas Blower Air',
                        'Sound System',
                        'Lampu Hias / Sorot',
                        'Kain Rempel / Dinding',
                      ].map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => handleAppendItem(item)}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-semibold rounded-md border border-slate-200 transition"
                        >
                          + {item}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bagian 4: Catatan Khusus Lapangan */}
              <div className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-xs font-bold tracking-wider text-[#8B0000] uppercase">
                    4. Catatan Khusus & Akses Lokasi
                  </h3>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Catatan Tambahan Lapangan / Akses Jalan
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Contoh: Masuk gang kecil seberang masjid, koordinasi dengan Bpk RT Joko..."
                      value={currentSchedule.notes || ''}
                      onChange={(e) =>
                        setCurrentSchedule((prev) => ({ ...prev, notes: e.target.value }))
                      }
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8B0000] bg-slate-50 focus:bg-white resize-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Live Paper Document Preview & Action Toolbar (Sticky) */}
            <div className="lg:col-span-6 space-y-4 lg:sticky lg:top-20">
              <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 text-xs font-bold tracking-wider text-slate-700 uppercase">
                    <Eye className="w-4 h-4 text-[#8B0000]" />
                    <span>PREVIEW LEMBAR JADWAL & SPK KERJA</span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-bold">
                    Live Real-Time
                  </span>
                </div>

                {/* The Paper Preview (Word Grid Table) */}
                <div className="bg-slate-100 p-2 sm:p-4 rounded-xl overflow-x-auto flex justify-center border border-slate-200">
                  <ScheduleDocumentPreview ref={previewRef} schedule={currentSchedule} />
                </div>
              </div>

              {/* Action Toolbar directly underneath the paper preview */}
              <ScheduleActionButtons
                schedule={currentSchedule}
                previewRef={previewRef}
                onSaveSchedule={handleSaveCurrentSchedule}
                onClearForm={handleResetCurrentSchedule}
                onShowToast={onShowToast}
              />
            </div>
          </div>
        </div>
      ) : (
        /* VIEW 2: TABEL LAPORAN (WORD / SPREADSHEET TABLE REKAP) */
        <ScheduleTableReport
          schedules={activeSchedules}
          title="Laporan Tabel Jadwal Pemasangan & Bongkar Tenda"
          isHistory={false}
          onEdit={handleEditFromTable}
          onDelete={onDeleteSchedule}
          onShare={(s) => setSharingSchedule(s)}
          onToggleStatus={onUpdateStatus}
          onShowToast={onShowToast}
        />
      )}

      {/* Share Modal if triggered from the table */}
      <ScheduleShareModal
        isOpen={!!sharingSchedule}
        schedule={sharingSchedule}
        onClose={() => setSharingSchedule(null)}
        onShowToast={onShowToast}
      />
    </div>
  );
};
