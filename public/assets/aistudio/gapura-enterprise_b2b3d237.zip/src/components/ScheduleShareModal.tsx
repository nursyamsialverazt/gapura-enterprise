import React, { useRef, useState, useMemo } from 'react';
import {
  X,
  Download,
  FileText,
  Share2,
  Copy,
  Check,
  Calendar,
  Clock,
  MapPin,
  Phone,
  User,
  HardHat,
  FileCheck,
  Printer,
  Loader2,
  ExternalLink,
} from 'lucide-react';
import { toPng, toJpeg } from 'html-to-image';
import { jsPDF } from 'jspdf';
import { ScheduleItem } from '../types';
import { formatDateTimeIndo } from '../utils/formatters';
import { GapuraLogo } from './Logo';

interface ScheduleShareModalProps {
  schedule: ScheduleItem | null;
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (message: string, type?: 'success' | 'info' | 'error') => void;
}

export const ScheduleShareModal: React.FC<ScheduleShareModalProps> = ({
  schedule,
  isOpen,
  onClose,
  onShowToast,
}) => {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const [isPngLoading, setIsPngLoading] = useState(false);
  const [isPdfLoading, setIsPdfLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Parse order items line by line into structured table rows
  const orderItemsList = useMemo(() => {
    if (!schedule?.orderDetails) return [];
    return schedule.orderDetails
      .split('\n')
      .map((item) => item.trim())
      .filter(Boolean);
  }, [schedule?.orderDetails]);

  if (!isOpen || !schedule) return null;

  const getCleanPhone = (p: string) => {
    let clean = p.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) {
      clean = '62' + clean.slice(1);
    }
    return clean;
  };

  const getWhatsAppMessage = () => {
    return `*SURAT PERINTAH KERJA (SPK) & JADWAL PASANG BONGKAR TENDA*
*GAPURA ENTERPRISE (Wedding & Event Solution)*
=============================================
*NO. JADWAL:* ${schedule.sourceInvoiceNumber || `JDWL-${schedule.id.slice(-6).toUpperCase()}`}
*STATUS:* ${schedule.status === 'AKTIF' ? 'AKTIF (BELUM BONGKAR)' : 'SELESAI BONGKAR'}

+-------------------------------------------+
| *DATA ACARA & PELAKSANAAN*
+-------------------------------------------+
• *Nama Tuan Hajat:* ${schedule.customerName || '-'}
• *Alamat Lokasi:* ${schedule.address || '-'}
• *Waktu Pasang:* ${formatDateTimeIndo(schedule.setupDate)}
• *Waktu Bongkar:* ${formatDateTimeIndo(schedule.teardownDate)}

+-------------------------------------------+
| *RINCIAN PESANAN TENDA & PERALATAN*
+-------------------------------------------+
${schedule.orderDetails || '-'}

${schedule.notes ? `+-------------------------------------------+\n| *CATATAN LAPANGAN / AKSES JALAN*\n+-------------------------------------------+\n${schedule.notes}\n` : ''}=============================================
_Lembar Instruksi Resmi Kru Lapangan_`;
  };

  const handleCopyWhatsAppText = async () => {
    try {
      const text = getWhatsAppMessage();
      await navigator.clipboard.writeText(text);
      setCopied(true);
      onShowToast('Teks jadwal WhatsApp berhasil disalin ke clipboard!', 'success');
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error(err);
      onShowToast('Gagal menyalin teks secara otomatis', 'error');
    }
  };

  const handleOpenWhatsApp = () => {
    const text = encodeURIComponent(getWhatsAppMessage());
    const cleanPhone = getCleanPhone(schedule.phone);
    const url = cleanPhone
      ? `https://wa.me/${cleanPhone}?text=${text}`
      : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  const handleDownloadImage = async () => {
    if (!cardRef.current) return;
    setIsPngLoading(true);
    try {
      // Allow DOM fonts and elements to settle
      await new Promise((r) => setTimeout(r, 200));

      const dataUrl = await toPng(cardRef.current, {
        cacheBust: true,
        pixelRatio: 2.5,
        backgroundColor: '#ffffff',
      });

      const fileName = `Tabel_Jadwal_Gapura_${schedule.customerName.replace(/[^a-zA-Z0-9]/g, '_') || 'Event'}.png`;
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 1000);

      onShowToast('Foto tabel jadwal (PNG) berhasil diunduh!', 'success');
    } catch (error) {
      console.error('Error generating schedule image:', error);
      onShowToast('Gagal membuat gambar tabel jadwal', 'error');
    } finally {
      setIsPngLoading(false);
    }
  };

  const handleDownloadPdf = async () => {
    if (!cardRef.current) return;
    setIsPdfLoading(true);
    const fileName = `Tabel_Jadwal_Gapura_${schedule.customerName.replace(/[^a-zA-Z0-9]/g, '_') || 'Event'}.pdf`;

    try {
      await new Promise((r) => setTimeout(r, 150));
      const imgData = await toJpeg(cardRef.current, {
        quality: 0.98,
        backgroundColor: '#ffffff',
        pixelRatio: 2.5,
      });

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgProps = pdf.getImageProperties(imgData);
      const margin = 12;
      const printWidth = pageWidth - margin * 2;
      const printHeight = (imgProps.height * printWidth) / imgProps.width;

      pdf.addImage(
        imgData,
        'JPEG',
        margin,
        margin,
        printWidth,
        Math.min(printHeight, pageHeight - margin * 2)
      );
      pdf.save(fileName);
      onShowToast('Dokumen PDF tabel jadwal berhasil diunduh!', 'success');
    } catch (error) {
      console.error('Error creating PDF:', error);
      onShowToast('Gagal membuat file PDF', 'error');
    } finally {
      setIsPdfLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full overflow-hidden flex flex-col max-h-[96vh] border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-[#8B0000] text-white px-4 sm:px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-white/10 rounded-xl">
              <FileText className="w-5 h-5 text-[#bef264]" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold leading-tight">
                Bagikan Laporan Jadwal (Format Tabel Word)
              </h2>
              <p className="text-[11px] text-white/80">
                Format tabel resmi Word siap kirim via Foto PNG, Dokumen PDF, atau WhatsApp
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2 items-center justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadImage}
              disabled={isPngLoading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#8B0000] hover:bg-[#700000] text-white rounded-xl text-xs font-bold shadow-sm transition disabled:opacity-50"
              title="Unduh foto tabel format PNG"
            >
              {isPngLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
              ) : (
                <Download className="w-3.5 h-3.5 text-[#bef264]" />
              )}
              <span>Unduh Foto (PNG)</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isPdfLoading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold shadow-sm transition disabled:opacity-50"
              title="Unduh file dokumen PDF"
            >
              {isPdfLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
              ) : (
                <FileText className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span>Unduh PDF</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold shadow-sm transition"
              title="Cetak langsung lewat printer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Cetak / Print</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleCopyWhatsAppText}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-semibold transition"
              title="Salin teks tabel untuk WhatsApp"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tersalin!' : 'Salin Teks WA'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenWhatsApp}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
              title="Buka chat WhatsApp"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Buka WA</span>
            </button>
          </div>
        </div>

        {/* Scrollable Preview Container */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-slate-200/70 flex justify-center">
          {/* WORD-STYLE TABLE DOCUMENT TARGET (Captured by html-to-image and jsPDF) */}
          <div
            ref={cardRef}
            className="w-full max-w-2xl bg-white shadow-lg border border-slate-400 p-5 sm:p-7 text-black font-sans leading-normal space-y-4 rounded-none"
            style={{ minHeight: '620px' }}
          >
            {/* Kop Surat Resmi Microsoft Word Style */}
            <div className="border-b-4 border-double border-black pb-2.5 text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <GapuraLogo size="sm" variant="icon" />
                <h1 className="text-xl font-black uppercase font-serif tracking-widest text-[#8B0000]">
                  GAPURA ENTERPRISE
                </h1>
              </div>
              <p className="text-[11px] font-black uppercase tracking-wider text-black">
                WEDDING & EVENT SOLUTION • SEWA TENDA, DEKORASI & ALAT PESTA
              </p>
              <p className="text-[10px] text-slate-700 mt-0.5">
                Alamat: Jl. Raya Pesta Gapura • Telp/WhatsApp: 0821-1887-0862 • Instagram: @gapuraenterprise
              </p>
            </div>

            {/* Document Header & SPK Title */}
            <div className="text-center my-2">
              <h2 className="text-sm font-black uppercase tracking-wider underline">
                SURAT PERINTAH KERJA (SPK) & JADWAL PASANG BONGKAR TENDA
              </h2>
              <div className="text-[10px] text-slate-600 font-mono mt-1 text-center font-bold">
                No. SPK: <strong>{schedule.sourceInvoiceNumber ? `SPK-${schedule.sourceInvoiceNumber}` : `SPK-GAPURA-${schedule.id.slice(-6).toUpperCase()}`}</strong>
              </div>
            </div>

            {/* TABEL 1: Data Acara & Pelaksanaan (Tabel Word bergaris hitam) */}
            <div>
              <div className="text-[11px] font-bold uppercase mb-1 text-black">
                A. Data Pemesan & Pelaksanaan Acara:
              </div>
              <table className="w-full text-xs border-collapse border border-black table-fixed">
                <tbody>
                  <tr>
                    <td className="w-36 border border-black bg-slate-100 p-2 font-bold text-slate-900">
                      Nama Tuan Hajat
                    </td>
                    <td className="border border-black p-2 font-bold text-black text-sm">
                      {schedule.customerName || '-'}
                    </td>
                  </tr>
                  <tr>
                    <td className="border border-black bg-slate-100 p-2 font-bold text-slate-900">
                      Alamat Lokasi Acara
                    </td>
                    <td className="border border-black p-2 text-black leading-relaxed">
                      {schedule.address || '-'}
                    </td>
                  </tr>
                  <tr>
                    <td className="border border-black bg-slate-100 p-2 font-bold text-slate-900">
                      Waktu Pasang
                    </td>
                    <td className="border border-black p-2 font-bold text-[#8B0000]">
                      {formatDateTimeIndo(schedule.setupDate)}
                    </td>
                  </tr>
                  <tr>
                    <td className="border border-black bg-slate-100 p-2 font-bold text-slate-900">
                      Waktu Bongkar
                    </td>
                    <td className="border border-black p-2 font-bold text-[#8B0000]">
                      {formatDateTimeIndo(schedule.teardownDate)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* TABEL 2: Rincian Pesanan Tenda & Peralatan (Tabel Grid Baris demi Baris Word) */}
            <div>
              <div className="text-[11px] font-bold uppercase mb-1 flex items-center justify-between text-black">
                <span>B. Rincian Pesanan Tenda & Peralatan Lapangan:</span>
                <span className="text-[10px] font-normal text-slate-500 italic">
                  *Kru wajib periksa kelengkapan barang saat muat & pasang
                </span>
              </div>
              <table className="w-full text-xs border-collapse border border-black">
                <thead>
                  <tr className="bg-slate-200 text-black font-bold">
                    <th className="border border-black p-1.5 text-center w-10">No</th>
                    <th className="border border-black p-1.5 text-left">Uraian Peralatan / Tenda</th>
                    <th className="border border-black p-1.5 text-center w-28">Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                  {orderItemsList.length > 0 ? (
                    orderItemsList.map((item, idx) => (
                      <tr key={idx} className={idx % 2 === 1 ? 'bg-slate-50/70' : ''}>
                        <td className="border border-black p-1.5 text-center font-bold">{idx + 1}</td>
                        <td className="border border-black p-1.5 font-medium">{item}</td>
                        <td className="border border-black p-1.5 text-center text-[10px] text-slate-700">
                          Sesuai Pesanan
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="border border-black p-3 text-center text-slate-500 italic">
                        {schedule.orderDetails || 'Tidak ada rincian pesanan tercatat'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* TABEL 3: Catatan Khusus Lapangan */}
            {schedule.notes && (
              <div>
                <div className="text-[11px] font-bold uppercase mb-1 text-black">
                  C. Catatan Khusus & Ketentuan Lapangan:
                </div>
                <div className="border border-black bg-slate-50 p-2 text-xs text-slate-800 leading-relaxed">
                  <strong>Catatan Khusus:</strong> {schedule.notes}
                </div>
              </div>
            )}

            {/* TABEL 4: Tanda Tangan & Serah Terima (Format Standar Word) */}
            <div className="pt-3">
              <table className="w-full text-xs border-0 text-center">
                <tbody>
                  <tr>
                    <td className="w-1/3 pb-14 text-slate-700">
                      Tuan Hajat / Keluarga
                    </td>
                    <td className="w-1/3 pb-14 text-slate-700">
                      Koordinator Kru Lapangan
                    </td>
                    <td className="w-1/3 pb-14 text-slate-700">
                      Pengelola Gapura Enterprise
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p className="font-bold text-black border-t border-black inline-block px-4 pt-1">
                        ( {schedule.customerName || '..............................'} )
                      </p>
                    </td>
                    <td>
                      <p className="font-bold text-black border-t border-black inline-block px-4 pt-1">
                        ( {schedule.picCrew || '..............................'} )
                      </p>
                    </td>
                    <td>
                      <p className="font-bold text-black border-t border-black inline-block px-4 pt-1">
                        ( Hendra / Admin )
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Footer Nota Word */}
            <div className="text-center pt-2 border-t border-slate-300 text-[9px] text-slate-500 font-mono">
              Dokumen resmi Gapura Enterprise • Simpan lembar kerja ini sebagai bukti verifikasi pemasangan & pembongkaran tenda.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-600 hidden sm:inline">
            Status: <strong className="text-slate-900">{schedule.status}</strong>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition"
          >
            Tutup Jendela
          </button>
        </div>
      </div>
    </div>
  );
};
