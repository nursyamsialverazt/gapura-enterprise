import { InvoiceData, PayrollData, ScheduleItem } from '../types';

const STORAGE_KEY = 'gapura_enterprise_invoices_v4';
const PAYROLL_STORAGE_KEY = 'gapura_enterprise_payrolls_v1';
const SCHEDULE_STORAGE_KEY = 'gapura_enterprise_schedules_v1';

export const getInvoicesFromStorage = (): InvoiceData[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      return [];
    }
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading from localStorage:', error);
    return [];
  }
};

export const saveInvoiceToStorage = (invoice: InvoiceData): InvoiceData[] => {
  try {
    const existing = getInvoicesFromStorage();
    const invoiceToSave = {
      ...invoice,
      id: invoice.id || `inv-${Date.now()}`,
      createdAt: invoice.createdAt || new Date().toISOString(),
    };

    const existingIndex = existing.findIndex((item) => item.id === invoiceToSave.id);
    let updated: InvoiceData[];

    if (existingIndex >= 0) {
      updated = [...existing];
      updated[existingIndex] = invoiceToSave;
    } else {
      updated = [invoiceToSave, ...existing];
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (error) {
    console.error('Error saving to localStorage:', error);
    return [];
  }
};

export const deleteInvoiceFromStorage = (idOrNumber: string): InvoiceData[] => {
  try {
    const existing = getInvoicesFromStorage();
    const filtered = existing.filter(
      (item) => item.id !== idOrNumber && item.invoiceNumber !== idOrNumber
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    return filtered;
  } catch (error) {
    console.error('Error deleting from localStorage:', error);
    return [];
  }
};

export const clearAllInvoicesFromStorage = (): InvoiceData[] => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
    return [];
  } catch (error) {
    console.error('Error clearing all invoices from localStorage:', error);
    return [];
  }
};

export const updateInvoiceStatusInStorage = (
  idOrNumber: string,
  paymentStatus: 'LUNAS' | 'BELUM_LUNAS' | 'AUTO'
): InvoiceData[] => {
  try {
    const existing = getInvoicesFromStorage();
    const updated = existing.map((item) => {
      if (item.id === idOrNumber || item.invoiceNumber === idOrNumber) {
        if (paymentStatus === 'AUTO') {
          const itemCopy = { ...item };
          delete itemCopy.paymentStatus;
          return itemCopy;
        }
        return {
          ...item,
          paymentStatus,
        };
      }
      return item;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (error) {
    console.error('Error updating invoice status in storage:', error);
    return [];
  }
};

// ======================== PAYROLL / PENGGAJIAN STORAGE ========================

export const getPayrollsFromStorage = (): PayrollData[] => {
  try {
    const data = localStorage.getItem(PAYROLL_STORAGE_KEY);
    if (!data) {
      return [];
    }
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading payrolls from localStorage:', error);
    return [];
  }
};

export const savePayrollToStorage = (payroll: PayrollData): PayrollData[] => {
  try {
    const existing = getPayrollsFromStorage();
    const payrollToSave: PayrollData = {
      ...payroll,
      id: payroll.id || `payroll-${Date.now()}`,
      createdAt: payroll.createdAt || new Date().toISOString(),
    };

    const existingIndex = existing.findIndex((item) => item.id === payrollToSave.id);
    let updated: PayrollData[];

    if (existingIndex >= 0) {
      updated = [...existing];
      updated[existingIndex] = payrollToSave;
    } else {
      updated = [payrollToSave, ...existing];
    }

    localStorage.setItem(PAYROLL_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (error) {
    console.error('Error saving payroll to localStorage:', error);
    return [];
  }
};

export const deletePayrollFromStorage = (id: string): PayrollData[] => {
  try {
    const existing = getPayrollsFromStorage();
    const filtered = existing.filter((item) => item.id !== id);
    localStorage.setItem(PAYROLL_STORAGE_KEY, JSON.stringify(filtered));
    return filtered;
  } catch (error) {
    console.error('Error deleting payroll from localStorage:', error);
    return [];
  }
};

export const clearAllPayrollsFromStorage = (): PayrollData[] => {
  try {
    localStorage.setItem(PAYROLL_STORAGE_KEY, JSON.stringify([]));
    return [];
  } catch (error) {
    console.error('Error clearing all payrolls from localStorage:', error);
    return [];
  }
};

// ======================== SCHEDULE / JADWAL STORAGE ========================

const getInitialDefaultSchedules = (): ScheduleItem[] => {
  const now = new Date();
  
  // Schedule 1: Setup tomorrow morning, teardown day after tomorrow
  const setup1 = new Date(now);
  setup1.setDate(now.getDate() + 1);
  setup1.setHours(8, 30, 0, 0);

  const teardown1 = new Date(now);
  teardown1.setDate(now.getDate() + 3);
  teardown1.setHours(9, 0, 0, 0);

  // Schedule 2: Setup today afternoon, teardown tomorrow night
  const setup2 = new Date(now);
  setup2.setHours(14, 0, 0, 0);

  const teardown2 = new Date(now);
  teardown2.setDate(now.getDate() + 1);
  teardown2.setHours(20, 0, 0, 0);

  // Format to YYYY-MM-DDTHH:mm
  const formatDateTime = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  return [
    {
      id: 'sch-sample-1',
      customerName: 'Bpk. H. Rahmat Mulyana',
      address: 'Jl. Pesantren No. 45 RT 02/05, Cibabat, Cimahi Utara',
      phone: '081223344556',
      orderDetails: '• Tenda Plafon VIP 8 x 15 Meter (Kain Maroon Gold)\n• Panggung Pelaminan 6 x 4 Meter + Karpet Merah\n• Kursi Futura + Sarung Pita (120 unit)\n• Sound System 5.000 Watt + 4 Mic Wireless\n• Kipas Blower Air Kabut (4 unit)',
      setupDate: formatDateTime(setup1),
      teardownDate: formatDateTime(teardown1),
      status: 'AKTIF',
      picCrew: 'Kang Deden (0821-9988-7711)',
      notes: 'Akses gang muat mobil engkel. Titik pasang di halaman depan rumah, listrik 2.200W aman.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'sch-sample-2',
      customerName: 'Ibu Hj. Siti Nurhaliza',
      address: 'Komplek Permata Indah Blok C3 No. 12, Sariwangi, Bandung Barat',
      phone: '085799112233',
      orderDetails: '• Tenda Roder Semi Dekorasi 10 x 20 Meter\n• Meja Prasmanan Bulat + Skirting (8 set)\n• AC Standing 5 PK (2 unit)\n• Genset Silent 30 KVA + Operator',
      setupDate: formatDateTime(setup2),
      teardownDate: formatDateTime(teardown2),
      status: 'AKTIF',
      picCrew: 'Kang Agus & Tim 4 Orang',
      notes: 'Bongkar malam setelah resepsi selesai jam 20.00. Hubungi Pak RT untuk izin parkir truk.',
      createdAt: new Date().toISOString(),
    },
  ];
};

export const getSchedulesFromStorage = (): ScheduleItem[] => {
  try {
    const data = localStorage.getItem(SCHEDULE_STORAGE_KEY);
    if (!data) {
      const initial = getInitialDefaultSchedules();
      localStorage.setItem(SCHEDULE_STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading schedules from localStorage:', error);
    return [];
  }
};

export const saveScheduleToStorage = (schedule: ScheduleItem): ScheduleItem[] => {
  try {
    const existing = getSchedulesFromStorage();
    const scheduleToSave: ScheduleItem = {
      ...schedule,
      id: schedule.id || `schedule-${Date.now()}`,
      createdAt: schedule.createdAt || new Date().toISOString(),
    };

    const existingIndex = existing.findIndex((item) => item.id === scheduleToSave.id);
    let updated: ScheduleItem[];

    if (existingIndex >= 0) {
      updated = [...existing];
      updated[existingIndex] = scheduleToSave;
    } else {
      updated = [scheduleToSave, ...existing];
    }

    localStorage.setItem(SCHEDULE_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (error) {
    console.error('Error saving schedule to localStorage:', error);
    return [];
  }
};

export const deleteScheduleFromStorage = (id: string): ScheduleItem[] => {
  try {
    const existing = getSchedulesFromStorage();
    const filtered = existing.filter((item) => item.id !== id);
    localStorage.setItem(SCHEDULE_STORAGE_KEY, JSON.stringify(filtered));
    return filtered;
  } catch (error) {
    console.error('Error deleting schedule from localStorage:', error);
    return [];
  }
};

export const updateScheduleStatusInStorage = (
  id: string,
  status: 'AKTIF' | 'SELESAI'
): ScheduleItem[] => {
  try {
    const existing = getSchedulesFromStorage();
    const updated = existing.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          status,
          completedAt: status === 'SELESAI' ? new Date().toISOString() : undefined,
        };
      }
      return item;
    });
    localStorage.setItem(SCHEDULE_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (error) {
    console.error('Error updating schedule status in localStorage:', error);
    return [];
  }
};

export const clearAllSchedulesFromStorage = (): ScheduleItem[] => {
  try {
    localStorage.setItem(SCHEDULE_STORAGE_KEY, JSON.stringify([]));
    return [];
  } catch (error) {
    console.error('Error clearing all schedules from localStorage:', error);
    return [];
  }
};

